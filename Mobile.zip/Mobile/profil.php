<?php
if (!isset($_GET['id'])) {
	header("Location: index.php");
	exit;
}

require 'functions.php';
$id = $_GET['id'];

$m = query("SELECT * FROM mobile WHERE id = $id")[0];
?>

<!DOCTYPE html>
<html>
<head>

	
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link rel="stylesheet" href="asset/css/bootstrap.css">
<!--     <link rel="stylesheet" type="text/css" href="asset/css/style.css"> -->

	<title>Profil</title>
</head>
<body>
	<div style="padding: 10px;">
		<h1 style="text-align: center; color: white;">Profil Mobil</h1>
	</div>

	<div class="card text-center" style="width: 28rem; margin: auto; margin-bottom: 15px; border: 2px solid #3498db;border-color: #2ecc71 ;">
  		<img src="asset/img/<?= $m['gambar']; ?>" class="card-img-top" class='rounded-circle'>
  		<div class="card-body" style="background-color: grey;">
    		<table class="table table-borderless">
				<tbody>
						    <tr>
						      	<td class="text-center h4">Merek Mobil</td>
						      	<td class="text-center h4">:</td>
						      	<td class="text-center h4"><?= $m['merek_mobil'] ?></td>
						    </tr>
						    <tr>
						      	<td class="text-center h4">Tipe Mobil</td>
						      	<td class="text-center h4">:</td>
						      	<td class="text-center h4"><?= $m['tipe_mobil'] ?></td>
						    </tr>
						    <tr>
						      	<td class="text-center h4">Tahun Keluar</td>
						      	<td class="text-center h4">:</td>
						      	<td class="text-center h4"> <?= $m['tahun_keluar'] ?></td>
						    </tr>
						    <tr>
						      	<td class="text-center h4">Harga </td>
						      	<td class="text-center h4">:</td>
						      	<td class="text-center h4">Rp. <?= $m['harga'] ?></td>
						    </tr>
						  </tbody>
					</table>
					<div class="text-center"><a href="tampilanuser.php"><button type="button" class="btn btn-dark">Kembali</button></a></div>
				</div>
			</div>
		</div>
	</div>

	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="asset/js/bootstrap.js"></script>
</body>
</html>