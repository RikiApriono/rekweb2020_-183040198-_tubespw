<?php
require 'functions.php';

$mobil = query("SELECT * FROM mobile");

if (isset($_POST['cari'])) {
	$mobil = cari($_POST['keyword']);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<!-- 	<style>
	body{

		background-image: url(asset/img/bmw4.jpg);
		background-size: cover;
	}
	.container {
background-color: green;
	}

	
	</style> -->
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link rel="stylesheet" href="asset/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="asset/css/style.css">

	<title>Index</title>
</head>
<body>
	<nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
	  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
	    <span class="navbar-toggler-icon"></span>
	  </button>
	  <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
	    <a class="navbar-brand" href="tampilanuser.php">Home</a>
	    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
	      <li class="nav-item active">
	        <a class="nav-link" href="Login.php"><button type="button" class="btn btn-info">Login Admin<span class="sr-only">(current)</span></button></a>
	      </li>
	    </ul>
	    <form class="form-inline my-2 my-lg-0" method="post" >
	      <input class="form-control mr-sm-2" type="text" name="keyword" autocomplete="off" id="keyword" placeholder="Search" aria-label="Search">
	      <button class="btn btn-light" type="submit"  name="cari" id="tombol-cari">Cari</button>

	    </form>

	  </div>
	  
	</nav>
	

	
	
<div id="carouselExampleSlidesOnly" class="carousel slide" data-ride="carousel" style="position: relative; top: 70px;">
	<div class="carousel-inner">
	    <div class="carousel-item active">
	        <img src="asset/img/bmw2.jpg" class="d-block w-100" alt="Responsive image" style="height: 540px;">
	    </div>
	    <div class="carousel-item">
	      	<img src="asset/img/bmw3.jpg" class="d-block w-100" alt="Responsive image" style="height: 540px;">
	    </div>
	    <div class="carousel-item">
	      	<img src="asset/img/bmw4.jpg" class="d-block w-100" alt="Responsive image" style="height: 540px;">
	    </div>
	    <div class="carousel-item">
	     	<img src="asset/img/bmw6.jpg" class="d-block w-100" alt="Responsive image" style="height: 540px;">
	    </div>
	</div>
</div>

<div class="huruf" style="position: relative; top: 100px;">
	<h1 style="color: white; text-align: center;">Daftar Mobil</h1>
</div>

<div id="container" style="padding: 35px; margin-top: 90px;">
	<?php foreach ($mobil as $m) : ?>
		<div class="card text-center" style="width: 24rem; display: inline-block; margin: 10px 5px; border: 3px solid #3498db;border-color: #2ecc71 ; ">
  			<a href="profil.php?id=<?= $m['id'] ?>"><img src="asset/img/<?= $m['gambar']; ?>" class="card-img-top"></a>
  			<div class="card-body" style="background-color: #343a40;">
    			<a href="profil.php?id=<?= $m['id'] ?>" class="h2 text-decoration-none" style="color: lightskyblue"><?= $m['merek_mobil']; ?></a>
  			</div>
  		</div>
  	<?php endforeach; ?>
</div>
<!-- </div> -->
	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="asset/js/bootstrap.js"></script>
    <script src="asset/js/script.js"></script>
    <script src="asset/js/jquery-3.3.1.min.js"></script>
</body>
</html>