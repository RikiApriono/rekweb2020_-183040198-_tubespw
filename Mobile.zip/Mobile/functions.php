<?php  
	function koneksi(){
		$conn = mysqli_connect("localhost", "root", "") or die("Koneksi ke DB gagal!");
		mysqli_select_db($conn, "Mobile") or die("Database salah!");
		return $conn;
		}

	function query($sql){
		$conn = koneksi();
		$result = mysqli_query($conn, "$sql");

		$rows = [];
		while ($row = mysqli_fetch_assoc($result)) {
			$rows[] = $row;
		};
		return $rows;
	}

	function tambah($data){
		$conn = koneksi();
		
		$merek = htmlspecialchars($data['merek_mobil']);
		$tipe = htmlspecialchars($data['tipe_mobil']);
		$tkeluar = htmlspecialchars($data['tahun_keluar']);
		$harga = htmlspecialchars($data['harga']);
		$id_merek= $data['id_merek'];

		$gambar = upload();
	if (!$gambar) {
		return false;
	}

		$query = "INSERT INTO mobile
							VALUES ('', '$tipe', '$merek', '$tkeluar', '$harga', '$gambar','$id_merek')";

		mysqli_query($conn, $query);

		return mysqli_affected_rows($conn);
	}

	function upload() {
	$namaFile = $_FILES['gambar']['name'];
	$ukuranFile = $_FILES['gambar']['size'];
	$error = $_FILES['gambar']['error'];
	$tmpName = $_FILES['gambar']['tmp_name'];

	if($error === 4) {
		echo "<script>
				alert('Pilih Gambar Terlebih Dahulu');
			</script>";

		return false;
	}

	$ekstensiGambarValid = ['jpg', 'jpeg', 'png'];
	$ekstensiGambar = explode('.', $namaFile);
	$ekstensiGambar = strtolower(end($ekstensiGambar));
	if(!in_array($ekstensiGambar, $ekstensiGambarValid)) {
		echo "<script>
				alert('Yang Anda Upload Bukan Gambar');
			</script>";

		return false;
	}
	if($ukuranFile > 1000000) {
		echo "<script>
				alert('Ukuran Gambar Terlalu Besar');
			</script>";

		return false;
	}

	$namaFileBaru = uniqid();
	$namaFileBaru .= '.';
	$namaFileBaru .= $ekstensiGambar;

	move_uploaded_file($tmpName, 'asset/img/' . $namaFileBaru);

	return $namaFileBaru;
}


	function hapus($id){
		$conn = koneksi();
		mysqli_query($conn, "DELETE FROM mobile WHERE id = $id");

		return mysqli_affected_rows($conn);
	}

	function ubah($data){
		$conn = koneksi();

		$id = $data['id'];
		
		$merek = htmlspecialchars($data['merek_mobil']);
		$tipe = htmlspecialchars($data['tipe_mobil']);
		$tkeluar = htmlspecialchars($data['tahun_keluar']);
		$harga = htmlspecialchars($data['harga']);
		$id_merek= $data['id_merek'];
		$gambarLama=  htmlspecialchars($data['gambarLama']);

		if ($_FILES['gambar']['error'] === 4) {
		$gambar = $gambarLama;
	} else {
		$gambar = upload();
	}

		$queryubah = " UPDATE  mobile
							SET 
							gambar='$gambar',
							tipe_mobil = '$tipe',
							merek_mobil = '$merek',
							id_merek = '$id_merek',
							tahun_keluar = '$tkeluar',
							harga = '$harga',
							gambar = '$gambar'
						WHERE id = '$id' ";

		mysqli_query($conn, $queryubah);

		return mysqli_affected_rows($conn);
	};


function cari($keyword){
	$query = "SELECT * FROM mobile 
				INNER JOIN merek ON mobile.id_merek = merek.id_merek WHERE
			tipe_mobil LIKE '%$keyword%' OR
			merek_mobil LIKE '%$keyword%' OR
			
			tahun_keluar LIKE '%$keyword%' OR
			harga LIKE '%$keyword%'

			";

			return query($query);

}



function registrasi($data) {

	$conn =koneksi();
	$username = $data['username'];
	$password1 = $data['password1'];
	$password2 = $data['password2'];


	$cek_user = mysqli_query($conn, "SELECT * FROM user WHERE username = '$username'");


	

	if ( mysqli_num_rows($cek_user) > 0){

		echo "<script>
		alert('username sudah terdaftar!');
		document.location.href= 'registrasi.php';
		</script>";
		return false;
	}

	if ($password1 != $password2) {


		echo "<script>
		alert('konfirmasi password salah!');
		document.location.href= 'registrasi.php';
		</script>";
		return false;
	}

	//username ok 

	$password = password_hash($password1, PASSWORD_DEFAULT);
	$query = "INSERT INTO user VALUES
				('','$username','$password')";
mysqli_query($conn, $query);

return mysqli_affected_rows($conn);

}



?>