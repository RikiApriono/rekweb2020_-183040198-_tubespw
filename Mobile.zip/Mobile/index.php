<?php  
	require ('functions.php');
	$mobile = query("SELECT * FROM mobile INNER JOIN merek ON mobile.id_merek=merek.id_merek");
	$i = 1;

//tombol cari ditekan

if(isset($_POST["cari"])){
	$mobile = cari($_POST["keyword"]);
}

?>
 <!DOCTYPE html>
<html>
<head>
	<title>Daftar Harga Mobil</title>
	 <!--  <link rel="stylesheet" type="text/css" href="asset/css/index.css"> -->
	  <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.1/css/all.css" integrity="sha384-50oBUHEmvpQ+1lW4y57PTFmhCaXp0ML5d60M1M7uH2+nqUivzIebhndOJK28anvf" crossorigin="anonymous">
<style>
	body{
  font-family: lato;

  background-color: white;
}
.navigation{
  list-style-type: none;
  top: 0;
  left: 0;
  margin: 0;
  padding: 0;
  overflow: hidden;
  width: 100%;
  background: #374760;
  font-size: 14px;
}
ul{
   list-style-type: none;
    margin: 0;
    padding: 0;
    overflow: hidden;
    background-color: #333;
}
li{
  float: left;
}
li a{
  display: block;
  color: white;
  text-align: center;
  text-decoration: none;
  padding: 16px 14px; 
  font-weight: bold;
}
li a:hover{
  background: red;
}
.active{
  background: #e31f1f;
  color: white;    
  float: left;
}
li a, .dropbtn {
    display: inline-block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
}
li a:hover, .dropdown:hover .dropbtn {
    background-color: red;
}
li.dropdown {
    display: inline-block;
}
.dropdown-content {
    display: none;
    position: absolute;
    background-color: #f9f9f9;
    min-width: 160px;
    box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
}
.dropdown-content a {
    color: black;
    padding: 12px 16px;
    text-decoration: none;
    display: block;
    text-align: left;
}
.dropdown-content a:hover {background-color: #f1f1f1}
.dropdown:hover 
.dropdown-content {
 display: block;
}

.cari {

  background:  red;
  border-radius: 10px;

}
table {

  background-color: black;
  color: white;
}
.lbl{
	text-align: center;
	color: red;

}
@media print {
.navigation, .lbl, .urutan, .opsi{
	display: none;

}




</style>
</head>
<body>




</head>
<body>

<ul class="navigation">
  <li class="active"><a href="index.php"><i class="fa fa-home"></i> HOME</a></li>
<li><a href="tambah.php"><i class="fas fa-plus"></i> TAMBAH DATA</a></li>
<li <i style="float:right;margin: 0px;margin-left: 14px;"><a href="tampilanuser.php"><i class="fas fa-sign-out-alt" align="left" class="logout"></i> LOGOUT</a>
      
    </div>
  </li>
  <i style="float:right;margin: 5px;margin-left: -14px;color: #fff; background: red;padding: 10px 18px;border-radius: 10px;" class=""><form action="" method="post" align="center">
        <input type="text" name="keyword" id="keyword" placeholder="Cari disini...." size="25" autocomplete="off">
        <button type="submit" class="cari" name="cari" id="tombol-cari">Cari</button>

      </form>
    </i>

</ul>
<br><br>
<label class="lbl">Urutkan berdasarkan :</label>
	<select id="urutan" class="urutan">
		
		<option value="merek_mobil">Merek Mobil</option>
		<option value="tahun_keluar">Tahun Keluar</option>
	</select>

	<div class="container" id="container">
		
		<!-- <button class="logout"><a href="tampilanuser.php" >Logout</a></button><br><br> -->
<br><br>		

		<!-- <center><a href="tambah.php"><button class="tambah">Tambah Data!</button></a></center> -->
		
		<!-- <br><br>
			<form action="" method="post" align="center">
				<input type="text" name="keyword" placeholder="Cari disini...." size="25" autocomplete="off">
				<button type="submit" name="cari">Cari</button>

			</form>
 -->
			<br><br>

			
		<table border="1" cellpadding="10" align="center">
			<tr>
				<th>#</th>
				<th>Gambar Mobil</th>
				<th>Merek Mobil</th>
				<th>Merek</th>
				<th>Tipe Mobil</th>
				<th>Tahun Keluar</th>
				<th>Harga</th>
				<th class="opsi">Opsi</th>
			</tr>
			<?php if(empty($mobile)) : ?>
		<tr>
			
			<td colspan="6" align="center">DATA NOT FOUND!!!!!!</td>

		</tr>

		<?php endif; ?>
			
		<?php foreach ($mobile as $m) : ?>
			<tr>
				<td><?=  $i++; ?></td>
				<td><img src="asset/img/<?= $m['gambar'] ?>" width="150px"></td>
				<td><?= $m['merek_mobil']; ?></td>
				<td><?= $m['nama_merek']; ?></td>
				<td><?= $m['tipe_mobil'] ; ?></td>
				<td><?= $m['tahun_keluar'];  ?></td>
				<td>Rp. <?= $m['harga'];  ?></td>
				<td class="opsi">
					<a href="ubah.php?id=<?= $m['id']; ?>">Edit |</a> <a href="hapus.php?id=<?= $m['id']; ?>" onclick="return confirm('Apakah anda ingin menghapusnya?');">Delete</a>
				</td>
			</tr>
		<?php endforeach; ?>
			
			
		</table>
	</div>


	<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
    <script src="asset/js/bootstrap.js"></script>
  	<script src="asset/js/script4.js"></script>
  	<script src="asset/js/script.js"></script>


</body>
</html> 