<?php  
	require ('functions.php');
	$id = $_GET['id'];
	$m = query("SELECT * FROM mobile WHERE id = $id")[0];
	
	if (isset($_POST['ubah'])) {
		if (ubah($_POST) > 0) {
			echo "<script>
					alert('Data berhasil diubah!');
					document.location.href='index.php';
				</script>";
		} else{
			echo "<script>
					alert('Data gagal diubah!');
					document.location.href='index.php';
				</script>";
		}

	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Ubah Daftar Mobil</title>
		<link rel="stylesheet" href="asset/css/style4.css">
</head>
<body>

	<h1>Ubah Daftar Mobil</h1>

	<form class="box" action="" method="post" enctype="multipart/form-data">
 		<input type="hidden" name="id" value="<?php echo $m['id']; ?>">
 		<input type="hidden" name="gambarLama" value="<?php echo $m['gambar']; ?>">


		<label for="gambar">Gambar Mobil :</label><br>
		<input type="file" name="gambar" id="gambar" value="<?php echo $m['gambar']; ?>"><br><br>

		<label for="merek_mobil">Merek Mobil :</label><br>
		<input type="text" name="merek_mobil" id="merek_mobil" value="<?php echo $m['merek_mobil']; ?>" required><br><br>

		<label for="id_merek">Merek :</label><br>
				<select name="id_merek">
					<option selected>Pilih Merek</option>

					<?php 

						$merek= query("SELECT * FROM merek");
						foreach($merek as $mrk) {

							echo '<option value="'.$mrk['id_merek'].'"">'. $mrk['nama_merek'].'</option>';
						}
					 ?>

				</select><br>

		<label for="tipe_mobil">Tipe Mobil :</label><br>
		<input type="text" name="tipe_mobil" id="tipe_mobil" value="<?php echo $m['tipe_mobil']; ?>" required><br><br>

		<label for="tahun_keluar">Tahun Keluar :</label><br>
		<input type="text" name="tahun_keluar" id="tahun_keluar" value="<?php echo $m['tahun_keluar']; ?>" required><br><br>

		<label for="harga">Harga :</label><br>
		<input type="text" name="harga" id="harga" value="<?php echo $m['harga']; ?>" required><br><br>

		<button type="submit" name="ubah">Ubah!</button>
		<a href="index.php"><button type="button">Kembali</button></a>
	</form> 

</body>
</html>