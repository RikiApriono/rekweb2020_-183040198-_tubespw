<?php
require 'functions.php';

if (isset($_POST['submit'])) {
	$conn = koneksi();
	$username = $_POST['username'];
	$password = $_POST['password'];
	$query = "SELECT * FROM user WHERE 
				username = '$username'";
	$cek_user = mysqli_query($conn, $query);

	if (mysqli_num_rows($cek_user) == 1) {
		//cek pass
		$user = mysqli_fetch_assoc($cek_user);
		if(password_verify($password,$user['password'])) {

			//ok , user bisa login

			$_SESSION['username'] = $username;
			header("Location: index.php");
			exit;
		} else {
			//password salah

			$error = 'password salah';
		}
	} else {
		//gagal
		$error = 'Username belum terdaftar!';
	}
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<style>
	body {

padding: 0;
margin: 0;
font-family: sans-serif;
background: white;


}

img {
			border-radius: 50%;
			width: 120px;

}

.box label{
	color: white;
}

.box {

	width: 300px;
	padding: 40px;
	position: absolute;
	top: 50%;
	left: 50%;
	transform: translate(-50%, -50%);
	background: rgb(241, 5, 5);
	text-align: center;
	border: 2px solid #3498db;
}

.box h1 {
	color: black;
	text-transform: uppercase;
	font-weight: 500;
}
.box input[type = "text"],.box input[type = "password"]{
	border: 0;
	background: none;
	display: block;
	margin: 20px auto;
	text-align: center;
	border: 2px solid #3498db;
	padding: 14px 10px;
	width: 200px;
	outline: none;
	color: white;
	border-radius: 24px;
	transition: 0.25s;
}

.box input[type = "text"]:focus,.box input[type = "password"]:focus{
	width: 280px;
	border-color: #2ecc71 ; 

}
.box input[type = "text"],.box input[type = "password"]{
	border: 0;
	background: none;
	display: block;
	margin: 20px auto;
	text-align: center;
	border: 2px solid #3498db;
	padding: 14px 10px;
	width: 200px;
	outline: none;
	color: white;
	border-radius: 24px;
	transition: 0.25s;
}

.box input[type = "text"]:focus,.box input[type = "password"]:focus{
	width: 280px;
	border-color: white ; 

}
.box button[type ="submit"]{
border: 0;
	background: none;
	display: block;
	margin: 20px auto;
	text-align: center;
	border: 2px solid  #2ecc71;
	padding: 14px 40px;
	width: 130px;
	outline: none;
	color: white;
	border-radius: 24px;
	transition: 0.25s;
	cursor: pointer;

}
.box button[type ="submit"]:hover{

background:  #2ecc71;

}



a { color:  blue;
	font-style: italic;


}
hr {

	border-color:  #3498db;
}
		}
		.use {
			margin: 7px;
			padding: 3px;
			padding-right: 30px;
		}
p{
	color: white;
}


</style>
	
</head>
<body>
<!-- 	<div class="container"> -->
	
	

	<?php if(isset($error)) : ?>
		<p><?= $error; ?></p>
	<?php endif; ?>

	<form class="box" method="post" action="">
		<h1>Login</h1>
		

		<!-- <label for="username">Username : </label> -->
		<input type="text" name="username" id="username" class="use" placeholder="username">

		<!-- <label for="password" class="pas">Password : </label> -->
		<input type="password" name="password" id="password" class="use" placeholder="password"> 
		
		<button type="submit" name="submit" class="sub">Login</button><br>

			<hr>
		<p>Belum punya account?<a class="b1" href="registrasi.php">Create Account</a>
	

	</form>
	
	</div>
</body>
</html>