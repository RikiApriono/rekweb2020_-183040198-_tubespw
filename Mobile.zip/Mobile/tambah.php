<?php  
	require ('functions.php');

	if (isset($_POST['tambah'])) {
		if (tambah($_POST, $_FILES) > 0) {
			echo "<script>
					alert('Data berhasil ditambahkan!');
					document.location.href = 'index.php';
				</script>";
		} else{
			echo "<script>
					alert('Data gagal ditambahkan!');
					document.location.href = 'index.php';
				</script>";
		}

	}
?>
<!DOCTYPE html>
<html>
<head>
	<title>Tambah Data Mobil</title>
	<link rel="stylesheet" href="asset/css/style5.css">
</head>
<body>

	<h1>Tambah Daftar Mobil</h1>

	<form class="box"  action="" method="post" enctype="multipart/form-data">
		<ul>	
			<li>
			<label for="gambar">Gambar Mobil :</label><br>
			<input type="file" name="gambar" id="gambar"><br><br>
			</li>

			<li>
			<label for="merek_mobil">Merek Mobil :</label><br>
			<input type="text" name="merek_mobil" id="merek_mobil" ><br><br>
			</li>
			<li>
				<label for="id_merek">Merek</label><br>
				<select name="id_merek">
					<option selected>Pilih Merek</option>

					<?php 

						$merek= query("SELECT * FROM merek");
						foreach($merek as $mrk) {

							echo '<option value="'.$mrk['id_merek'].'"">'. $mrk['nama_merek'].'</option>';
						}
					 ?>

				</select>

			</li>
			<li>
			<label for="tipe_mobil">Tipe Mobil :</label><br>
			<input type="text" name="tipe_mobil" id="tipe_mobil" ><br><br>
			</li>

			<li>
			<label for="tahun_keluar">Tahun Keluar :</label><br>
			<input type="text" name="tahun_keluar" id="tahun_keluar" ><br><br>
			</li>

			<li>
			<label for="harga">Harga :</label><br>
			<input type="text" name="harga" id="harga" ><br><br>
			</li>

			<button type="submit" name="tambah">Tambah!</button>
			<a href="index.php"><button type="button">Kembali</button></a>
		</ul>
	</form> 

</body>
</html>
