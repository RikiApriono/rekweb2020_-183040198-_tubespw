<?php
require '../../functions.php';

$keyword = $_GET['keyword'];

$query = "SELECT * FROM mobile 
			WHERE 
		merek_mobil LIKE '%$keyword%'";

$mobil = query($query);
?>





<?php foreach ($mobil as $m) : ?>
	<div class="card text-center" style="width: 24rem; display: inline-block; margin: 10px 5px; border: 3px solid #3498db;border-color: #2ecc71 ; ">
  			<a href="profil.php?id=<?= $m['id'] ?>"><img src="asset/img/<?= $m['gambar']; ?>" class="card-img-top"></a>
  			<div class="card-body" style="background-color: #343a40;">
    			<a href="profil.php?id=<?= $m['id'] ?>" class="h2 text-decoration-none" style="color: lightskyblue"><?= $m['merek_mobil']; ?></a>
  			</div>
  		</div>
<?php endforeach; ?>

