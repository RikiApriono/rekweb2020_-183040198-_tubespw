<?php
require '../../functions.php';

$urutan = $_GET['urutan'];

$sorting = "SELECT * FROM mobile INNER JOIN merek ON mobil.id_merek = merek.id_merek ORDER BY $urutan ASC";

$mobil = query($sorting);
?>

<div class="card" style=" background-color: #343a40;">
  <div class="card-body text-center">
    <h1 style="color: lightskyblue;">Data Tidak Ditemukan</h1>
  </div>
</div>

<?php foreach ($mobil as $m) : ?>
		<div class="card text-center" style="width: 24rem; display: inline-block; margin: 10px 5px">
  			<a href="profil.php?id=<?= $m['id'] ?>"><img src="../assets/img/<?= $m['gambar']; ?>" class="card-img-top"></a>
  			<div class="card-body" style="background-color: #343a40;">
    			<a href="profil.php?id=<?= $m['id'] ?>" class="h2 text-decoration-none" style="color: lightskyblue"><?= $m['merek_mobil']; ?></a>
  			</div>
  	</div>
		</table>
 