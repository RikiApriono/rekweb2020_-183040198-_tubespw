<?php
require '../../functions.php';

$keyword = $_GET['keyword'];

$query = "SELECT * FROM mobile INNER JOIN merek ON mobile.id_merek=merek.id_merek
			WHERE 
		merek_mobil LIKE '%$keyword%'";

$mobil = query($query);
$i = 1;	
?>

		<?php if(empty($mobile)) : ?>
		<table border="1" cellpadding="10" align="center">
			<tr>
				<th>#</th>
				<th>Gambar Mobil</th>
				<th>Merek Mobil</th>
				<th>Merek</th>
				<th>Tipe Mobil</th>
				<th>Tahun Keluar</th>
				<th>Harga</th>
				<th>Opsi</th>
			</tr>
		

		
			
		<?php foreach ($mobil as $m) : ?>
			<tr>
				<td><?=  $i++; ?></td>
				<td><img src="asset/img/<?= $m['gambar'] ?>" width="150px"></td>
				<td><?= $m['merek_mobil']; ?></td>
				<td><?= $m['nama_merek']; ?></td>
				<td><?= $m['tipe_mobil'] ; ?></td>
				<td><?= $m['tahun_keluar'];  ?></td>
				<td>Rp. <?= $m['harga'];  ?></td>
				<td>
					<a href="ubah.php?id=<?= $m['id']; ?>">Edit |</a> <a href="hapus.php?id=<?= $m['id']; ?>" onclick="return confirm('Apakah anda ingin menghapusnya?');">Delete</a>
				</td>
			</tr>
		<?php endforeach; ?>
			
			
		</table>
		<?php endif; ?>