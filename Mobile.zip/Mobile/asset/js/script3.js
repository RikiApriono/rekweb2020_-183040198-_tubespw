$(document).ready(function() {
	$('#tombol-cari').hide();

	$('#keyword').on('keyup', function() {
		$('#container').load('asset/ajax/mobil2.php?keyword=' + $('#keyword').val())
	});
});

$('.carousel').carousel({
  interval: 200
})