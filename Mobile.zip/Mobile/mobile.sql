-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 11, 2019 at 06:49 AM
-- Server version: 10.1.36-MariaDB
-- PHP Version: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `mobile`
--

-- --------------------------------------------------------

--
-- Table structure for table `merek`
--

CREATE TABLE `merek` (
  `id_merek` int(11) NOT NULL,
  `nama_merek` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `merek`
--

INSERT INTO `merek` (`id_merek`, `nama_merek`) VALUES
(1, 'Honda'),
(2, 'Toyota'),
(3, 'Mitsubishi');

-- --------------------------------------------------------

--
-- Table structure for table `mobile`
--

CREATE TABLE `mobile` (
  `id` int(12) NOT NULL,
  `tipe_mobil` varchar(30) NOT NULL,
  `merek_mobil` varchar(30) NOT NULL,
  `tahun_keluar` int(10) NOT NULL,
  `harga` int(15) NOT NULL,
  `gambar` varchar(20) NOT NULL,
  `id_merek` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `mobile`
--

INSERT INTO `mobile` (`id`, `tipe_mobil`, `merek_mobil`, `tahun_keluar`, `harga`, `gambar`, `id_merek`) VALUES
(1, 'Mini bus', 'Honda Jazz', 2016, 300000000, '2.jpg', 1),
(2, 'Mini bus', 'Xpander', 2015, 500000000, '5cd5efc25e02e.jpg', 3),
(3, 'Mini bus', 'Velfire', 2017, 1000000000, '5cd5effdd251f.jpg', 2),
(4, 'Sedan', 'Honda Civic ', 2017, 600000000, '5cd5f0604135c.jpg', 1),
(5, 'Mini bus', 'Honda Brv', 2016, 350000000, '19.jpg', 1),
(6, 'Mini bus', 'Mitsubishi pajero sport', 2016, 500000000, '6.jpg', 3),
(7, 'Mini bus', 'Toyota voxy', 2016, 600000000, '7.jpg', 2),
(8, 'Mini bus', 'Toyota Rush', 2014, 300000000, '8.jpg', 2),
(9, 'Mini bus', 'Toyota Alphard', 2016, 800000000, '5cd5ee8e1558c.jpg', 2),
(10, 'Mini bus', 'Toyota Yaris', 2015, 300000000, '10.jpg', 2),
(11, 'Sedan', 'Toyota Camry', 2019, 500000000, '5cd59c47bbe03.jpg', 2),
(12, 'mini bus', 'Toyota Etios', 2017, 180000000, '5cd59c85f0422.jpg', 2);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(250) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`) VALUES
(1, 'admin', '$2y$10$68ZXpZVw4M4fRQGMr0Ijl.ET94ucohdk8N8jerDrcdvrhvz5C02hu'),
(10, 'elgin', '$2y$10$JmZdMwKrISvLCDqLqeO9Ye60ZNe2yuHM.J/udArA5ufuqfODy.mXC'),
(11, 'deza', '$2y$10$S7YnG9D0zxqM61sFbkwVDOSJEVqrNc8wHvo5jKKMUJ3yLjBAhp5iq'),
(12, 'rita', '$2y$10$rQyf7k3twZDoOvnZoO1d6OvAdpQN0/fHR.AEFJV17BIbYqWuhoena');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `merek`
--
ALTER TABLE `merek`
  ADD PRIMARY KEY (`id_merek`);

--
-- Indexes for table `mobile`
--
ALTER TABLE `mobile`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_merek` (`id_merek`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `merek`
--
ALTER TABLE `merek`
  MODIFY `id_merek` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `mobile`
--
ALTER TABLE `mobile`
  MODIFY `id` int(12) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `mobile`
--
ALTER TABLE `mobile`
  ADD CONSTRAINT `mobile_ibfk_1` FOREIGN KEY (`id_merek`) REFERENCES `merek` (`id_merek`) ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
