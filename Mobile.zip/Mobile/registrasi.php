<?php
require 'functions.php';


if(isset($_POST['registrasi'])) {
	if(registrasi($_POST) > 0) {

		echo "<script>
		alert('Registrasi Berhasil');
		document.location.href = 'login.php';
		</script>";
	}
}




?>



<!DOCTYPE html>
<html>
<head>
	<title>	</title>

	<style>
		body {

padding: 0;
margin: 0;
font-family: sans-serif;
background: white;


}

img {
			border-radius: 50%;
			width: 120px;

}

.box label{
	color: white;
}

.box {

	width: 300px;
	padding: 40px;
	position: absolute;
	top: 50%;
	left: 50%;
	transform: translate(-50%, -50%);
	background: blue;
	text-align: center;
	border: 2px solid #3498db;
}

.box h1 {
	color: #2ecc71;
	text-transform: uppercase;
	font-weight: 500;
}
.box input[type = "text"],.box input[type = "password"]{
	border: 0;
	background: none;
	display: block;
	margin: 20px auto;
	text-align: center;
	border: 2px solid #3498db;
	padding: 14px 10px;
	width: 200px;
	outline: none;
	color: white;
	border-radius: 24px;
	transition: 0.25s;
}

.box input[type = "text"]:focus,.box input[type = "password"]:focus{
	width: 280px;
	border-color: #2ecc71 ; 

}
.box input[type = "text"],.box input[type = "password"]{
	border: 0;
	background: none;
	display: block;
	margin: 20px auto;
	text-align: center;
	border: 2px solid #3498db;
	padding: 14px 10px;
	width: 200px;
	outline: none;
	color: white;
	border-radius: 24px;
	transition: 0.25s;
}

.box input[type = "text"]:focus,.box input[type = "password"]:focus{
	width: 280px;
	border-color: #2ecc71 ; 

}
.box button[type ="submit"]{
border: 0;
	background: none;
	display: block;
	margin: 20px auto;
	text-align: center;
	border: 2px solid  #2ecc71;
	padding: 14px 40px;
	width: 140px;
	outline: none;
	color: white;
	border-radius: 24px;
	transition: 0.25s;
	cursor: pointer;

}
.box button[type ="submit"]:hover{

background:  #2ecc71;

}



a { color:  #2ecc71;
	font-style: italic;


}
hr {

	border-color:  #3498db;
}
	</style>
</head>
<body>



<form class="box" action="" method="post">	
	<h1>Registrasi</h1>
`		
			
		<input type="text" name="username" placeholder="username"required>

		<input type="password" name="password1" placeholder="password"  required>

		<input type="password" name="password2" placeholder="konfirmasi password" required>

		<button type="submit" name="registrasi" value="registrasi">Registrasi</button>


		

</form>

</body>
</html>